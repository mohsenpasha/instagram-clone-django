from django.shortcuts import render
from django.contrib.auth import authenticate, login
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.permissions import AllowAny
from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework.permissions import IsAuthenticated
from rest_framework_simplejwt.authentication import JWTAuthentication
from rest_framework.pagination import LimitOffsetPagination

from .authentication import CookieJWTAuthentication
from .serializers import PostListSerializer, PostSerializer, UserSimpleSerializer, UserHoverSerializer, UserSerializer, CommentSerializer, HashtagSerializers
from django.middleware.csrf import get_token

from . import models
import time
class LoginView(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        username = request.data.get("username")
        password = request.data.get("password")

        user = authenticate(username=username, password=password)
        login(request,user)
        if user is not None:
            refresh = RefreshToken.for_user(user)
            response = Response({
                "message": "Login successful"
            })

            response.set_cookie(
                key="access_token",
                value=str(refresh.access_token),
                httponly=True,
                samesite="Lax",
                secure=False
            )
            response.set_cookie(
                "csrftoken", get_token(request), 
                httponly=False,
                secure=False,
                samesite="Lax"
            )
            response.set_cookie(
                key="refresh_token",
                value=str(refresh),
                httponly=True,
                samesite="Lax",
                secure=False
            )

            return response
        return Response({"error": "Invalid credentials"}, status=400)


class ProtectedView(APIView):
    authentication_classes = [CookieJWTAuthentication]
    permission_classes = [IsAuthenticated]
    def get(self, request):
        return Response({"message": "You are authenticated"})


class LogoutView(APIView):
    def post(self, request):
        response = Response({"message": "Logged out"})
        response.delete_cookie("access_token")
        response.delete_cookie("refresh_token")
        return response

class UserPosts(APIView):
    class Pagination(LimitOffsetPagination):
        default_limit = 12
        max_limit = 100

    def get(self, request, username):
        posts = models.Post.objects.filter(user__username=username).order_by('-created_at')
        paginator = self.Pagination()
        paginated_posts = paginator.paginate_queryset(posts, request)
        serializer = PostListSerializer(paginated_posts,many=True)
        return paginator.get_paginated_response(serializer.data)


class GetPost(APIView):
    def get(self, request, postId):
        post = models.Post.objects.get(pk=postId)
        serializer = PostSerializer(post,context={'request': request})
        return Response(serializer.data)


class LikePost(APIView):
    authentication_classes = [CookieJWTAuthentication]
    permission_classes = [IsAuthenticated]
    def post(self, request, postId):
        postLike = models.PostLike.objects.filter(post=postId,user=request.user).exists()
        if(postLike):
            return Response({"error": "The post has already been liked."}, status=400)
        else:
            post = models.Post.objects.get(pk=postId)
            newPostLike = models.PostLike.objects.create(user=request.user,post=post)
            return Response({"message": "The post was successfully liked."}, status=200)

class UnlikePost(APIView):
    authentication_classes = [CookieJWTAuthentication]
    permission_classes = [IsAuthenticated]
    def post(self, request, postId):
        postLike = models.PostLike.objects.filter(post=postId,user=request.user)
        if(postLike.exists()):
            postLike.delete()
            return Response({"message": "The post was successfully unliked."}, status=200)
        else:
            return Response({"error": "The post has not been liked yet."}, status=400)



class SavePost(APIView):
    authentication_classes = [CookieJWTAuthentication]
    permission_classes = [IsAuthenticated]
    def post(self, request, postId):
        postLike = models.PostSave.objects.filter(post=postId,user=request.user).exists()
        if(postLike):
            return Response({"error": "The post has already been saved."}, status=400)
        else:
            post = models.Post.objects.get(pk=postId)
            newPostLike = models.PostSave.objects.create(user=request.user,post=post)
            return Response({"message": "The post was successfully saved."}, status=200)

class UnsavePost(APIView):
    authentication_classes = [CookieJWTAuthentication]
    permission_classes = [IsAuthenticated]
    def post(self, request, postId):
        postLike = models.PostSave.objects.filter(post=postId,user=request.user)
        if(postLike.exists()):
            postLike.delete()
            return Response({"message": "The post was successfully unsaved."}, status=200)
        else:
            return Response({"error": "The post has not been saved yet."}, status=400)


class GetPostLikes(APIView):
    class Pagination(LimitOffsetPagination):
        default_limit = 12
        max_limit = 100

    def get(self, request, postId):
        postLikes = models.PostLike.objects.filter(post=postId).order_by('-created_at')
        paginator = self.Pagination()
        paginated_likes = paginator.paginate_queryset(postLikes, request)
        users = [like.user for like in paginated_likes] 
        serializer = UserSimpleSerializer(users,many=True,context={'request': request})
        return paginator.get_paginated_response(serializer.data)

class GetUserFollowers(APIView):
    authentication_classes = [CookieJWTAuthentication]
    permission_classes = [IsAuthenticated]
    class Pagination(LimitOffsetPagination):
        default_limit = 12
        max_limit = 100

    def get(self, request, username):
        user = models.CustomUser.objects.get(username=username)
        userFollowers = models.Follower.objects.filter(following=user)
        paginator = self.Pagination()
        paginated_followers = paginator.paginate_queryset(userFollowers, request)
        users = [item.follower for item in paginated_followers]
        serializer = UserSimpleSerializer(users,many=True,context={'request': request})
        return paginator.get_paginated_response(serializer.data)

class GetUserFollowing(APIView):
    authentication_classes = [CookieJWTAuthentication]
    permission_classes = [IsAuthenticated]
    class Pagination(LimitOffsetPagination):
        default_limit = 12
        max_limit = 100

    def get(self, request, username):
        user = models.CustomUser.objects.get(username=username)
        userFollowers = models.Follower.objects.filter(follower=user)
        paginator = self.Pagination()
        paginated_followers = paginator.paginate_queryset(userFollowers, request)
        users = [item.following for item in paginated_followers]
        serializer = UserSimpleSerializer(users,many=True,context={'request': request})
        return paginator.get_paginated_response(serializer.data)

class AddPostComment(APIView):
    authentication_classes = [CookieJWTAuthentication]
    permission_classes = [IsAuthenticated]
    def post(self, request):
        post_id = request.data.get('postId',None)
        comment = request.data.get('comment')
        try:
            replied_to = models.Comment.objects.get(pk=request.data.get('replied_to'))
        except:
            replied_to = None
        try:
            post = models.Post.objects.get(pk=post_id)
        except:
            return Response({"message": "there ain't no such post boy"}, status=400)
        print(post_id,comment,replied_to)
        newComment = models.Comment.objects.create(post=post, comment=comment, user=request.user, replied_to=replied_to)
        serializer = CommentSerializer(newComment,context={'request': request})
        # postLike = models.PostLike.objects.filter(post=postId,user=request.user).exists()
        # if(postLike):
        #     return Response({"error": "The post has already been liked."}, status=400)
        # else:
        #     post = models.Post.objects.get(pk=postId)
        #     newPostLike = models.PostLike.objects.create(user=request.user,post=post)
        return Response(serializer.data, status=200)


class GetPostComments(APIView):
    authentication_classes = [CookieJWTAuthentication]
    permission_classes = [IsAuthenticated]
    class Pagination(LimitOffsetPagination):
        default_limit = 5
        max_limit = 100

    def get(self, request, postId):
        time.sleep(1)
        post = models.Post.objects.get(pk=postId)
        comments = models.Comment.objects.filter(post=post,replied_to__isnull=True)
        paginator = self.Pagination()
        paginated_comments = paginator.paginate_queryset(comments, request)
        serializer = CommentSerializer(paginated_comments,many=True,context={'request': request})
        return paginator.get_paginated_response(serializer.data)



class GetCommentReplies(APIView):
    authentication_classes = [CookieJWTAuthentication]
    permission_classes = [IsAuthenticated]

    class Pagination(LimitOffsetPagination):
        default_limit = 3
        max_limit = 100

    def get_replies_recursive(self, comment, request):
        replies = comment.replies.all()
        serialized_replies = CommentSerializer(replies, many=True, context={'request': request, 'show_reply_count': False}).data
        for reply, serialized_reply in zip(replies, serialized_replies):
            print(len(self.get_replies_recursive(reply, request)))
            if(len(self.get_replies_recursive(reply, request)) != 0):
                serialized_reply["replies"] = self.get_replies_recursive(reply, request)
        return serialized_replies

    def get(self, request, commentId):
        time.sleep(1)
        try:
            comment = models.Comment.objects.get(pk=commentId)
        except models.Comment.DoesNotExist:
            return Response({"error": "کامنت مورد نظر یافت نشد."}, status=404)

        replies = models.Comment.objects.filter(replied_to=comment)

        paginator = self.Pagination()
        paginated_replies = paginator.paginate_queryset(replies, request)
        serialized_replies = CommentSerializer(paginated_replies, many=True, context={'request': request, 'show_reply_count': False}).data

        for reply, serialized_reply in zip(paginated_replies, serialized_replies):
            serialized_reply["replies"] = self.get_replies_recursive(reply, request)

        return paginator.get_paginated_response(serialized_replies)

class LikeComment(APIView):
    authentication_classes = [CookieJWTAuthentication]
    permission_classes = [IsAuthenticated]
    def post(self, request, commentId):
        commentLike = models.CommentLike.objects.filter(comment=commentId,user=request.user).exists()
        if(commentLike):
            return Response({"error": "The comment has already been liked."}, status=400)
        else:
            comment = models.Comment.objects.get(pk=commentId)
            models.CommentLike.objects.create(user=request.user,comment=comment)
            return Response({"message": "The comment was successfully liked."}, status=200)

class UnlikeComment(APIView):
    authentication_classes = [CookieJWTAuthentication]
    permission_classes = [IsAuthenticated]
    def post(self, request, commentId):
        commentLike = models.CommentLike.objects.filter(comment=commentId,user=request.user)
        if(commentLike.exists()):
            commentLike.delete()
            return Response({"message": "The comment was successfully unliked."}, status=200)
        else:
            return Response({"error": "The comment has not been liked yet."}, status=400)


class GetCommentLikes(APIView):
    authentication_classes = [CookieJWTAuthentication]
    permission_classes = [IsAuthenticated]
    class Pagination(LimitOffsetPagination):
        default_limit = 12
        max_limit = 100

    def get(self, request, commentId):
        comment = models.Comment.objects.get(pk=commentId)
        comment_like = models.CommentLike.objects.filter(comment=comment)
        paginator = self.Pagination()
        paginated_comment_likes = paginator.paginate_queryset(comment_like, request)
        users = [item.user for item in paginated_comment_likes]
        serializer = UserSimpleSerializer(users,many=True,context={'request': request})
        print('serializer.data')
        print(serializer.data)
        return paginator.get_paginated_response(serializer.data)


class FollowUser(APIView):
    authentication_classes = [CookieJWTAuthentication]
    permission_classes = [IsAuthenticated]
    def post(self, request, username):
        time.sleep(1)
        if(username == request.user.username):
            return Response({"error": "sorry you can't follow yourself"}, status=400)
        is_following = models.Follower.objects.filter(follower__username=request.user.username,following__username=username).exists()
        if(is_following):
            return Response({"error": "The user has already been followed."}, status=400)
        else:
            user = models.CustomUser.objects.get(username=username)
            newFollower = models.Follower.objects.create(follower=request.user,following=user)
            return Response({"message": "The user was successfully followed."}, status=200)

class UnfollowUser(APIView):
    authentication_classes = [CookieJWTAuthentication]
    permission_classes = [IsAuthenticated]
    def post(self, request, username):
        time.sleep(1)
        if(username == request.user.username):
            return Response({"error": "sorry you can't unfollow yourself"}, status=400)
        is_following = models.Follower.objects.filter(follower__username=request.user.username,following__username=username)
        if(is_following.exists()):
            is_following.delete()
            return Response({"message": "The user was successfully unfollowed."}, status=200)
        else:
            return Response({"error": "The user is not in your following list."}, status=400)


class GetUserHoverPreview(APIView):
    def get(self, request, username):
        user = models.CustomUser.objects.get(username=username)
        serializer = UserHoverSerializer(user,context={'request': request})
        return Response(serializer.data)

class GetUserInfo(APIView):
    def get(self, request, username):
        user = models.CustomUser.objects.get(username=username)
        serializer = UserSerializer(user,context={'request': request})
        return Response(serializer.data)


class SearchUsersAndTags(APIView):
    authentication_classes = [CookieJWTAuthentication]
    # permission_classes = [IsAuthenticated]
    def post(self, request,searchType):
        time.sleep(1)
        searchInput = request.data.get('s',None)
        if(searchType == 'user'):
            result = models.CustomUser.objects.filter(username__icontains=searchInput)[:5]
            serializer = UserSimpleSerializer(result,many=True,context={'request': request})
        else:
            result = models.Hashtag.objects.filter(name__icontains=searchInput)[:5]
            serializer = HashtagSerializers(result,many=True)

            print('test')

        return Response(serializer.data, status=200)
